var $ = jQuery;



function updateMvctvSettings(setting_name,setting_val){
	var data = {
        'action': 'request_ajax',
	    'mvctv_action': 'mvctv_update_settings',
        'mvctv_args': {
            'setting_name': setting_name,
            'setting_val': setting_val
        }	        
    };
    $.post(ajaxurl, data, function(response) {
        location.reload();
    	
        //var raise_message_url = document.location + '&lk_raise_type=success&lk_raise_msg=The product '+item_name+' hase change to ' + item_val;
    	//window.location = raise_message_url;
    	
        
    });	
}