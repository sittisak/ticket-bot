<?php

$api_key = '7I75XMk5Gxt3xfTwDD1QbaOY1YiiJ2YR';

?>
