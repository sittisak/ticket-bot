<?php


function mvctv_install(){
    return true;
	global $wpdb;

	/* Create DB Schema and Default Data */
	$charset_collate = $wpdb->get_charset_collate();
	
	$table = $wpdb->prefix . "mvctv_lic_account_info";
	if ($wpdb->get_var("show tables like '$table'") != $table) {
		$structure = "CREATE TABLE ".$table." (
		lic_account_ID int(11) NOT NULL AUTO_INCREMENT,
		lic_account_user_name varchar(128) NOT NULL,
		lic_account_password varchar(64) NOT NULL,
		lic_app_type_ID varchar(11) NOT NULL,
		lic_client_group_type_ID varchar(11) NOT NULL,
		PRIMARY KEY (lic_account_ID)
		) $charset_collate;";
		$wpdb->query($structure);	
	}
	
	$table = $wpdb->prefix . "mvctv_lic_account_queue";
	if ($wpdb->get_var("show tables like '$table'") != $table) {
		$structure = "CREATE TABLE ".$table." (
		lic_account_queue_ID int(11) NOT NULL AUTO_INCREMENT,
		tmp_user_ID varchar(11) NOT NULL,
		lic_account_ID varchar(11) NOT NULL,		
		from_time varchar(11) NOT NULL,
		to_time varchar(11) NOT NULL,				
		PRIMARY KEY (lic_account_queue_ID)
		) $charset_collate;";
		$wpdb->query($structure);
	}
	
	
	/* Create WP Post */
	$mvctv_pages = array();

	$mvctv_pages['mvctv_db_select']['post_title'] = 'Select DB';
	$mvctv_pages['mvctv_db_select']['post_content'] = '[mvctv_db_select_views]';
	
	$mvctv_pages['mvctv_db_login']['post_title'] = 'Login to DB';
	$mvctv_pages['mvctv_db_login']['post_content'] = '[mvctv_db_login]';

	
	foreach($mvctv_pages as $page_name=>$value){
		$page['post_name'] = $page_name;
		$page['post_title'] = $mvctv_pages[$page_name]['post_title'];
		$page['post_content'] = $mvctv_pages[$page_name]['post_content'];
		$page['post_status'] = 'publish';
		$page['ping_status'] = 'closed';
		$page['comment_status'] ='closed';
		$page['post_type'] = 'page';
		$post_id = wp_insert_post( $page );
	}

}

?>