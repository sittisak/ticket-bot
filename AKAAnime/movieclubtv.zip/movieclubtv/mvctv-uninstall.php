<?php 

function mvctv_uninstall(){
    return true;
	global $wpdb;

	
	/* Drop mvctv table */
	$etable[] = $wpdb->prefix . "mvctv_lic_account_info";
	$etable[] = $wpdb->prefix . "mvctv_lic_account_queue";
		
	foreach($etable as $table){
		$wpdb->query("DROP TABLE IF EXISTS $table");
	}

	/* Delete mvctv post record */
	$table = $wpdb->prefix . "posts";
	$wpdb->query("DELETE from $table WHERE post_content like '%mvctv__%'");
    
    
    
}

?>