<?php



function mvctv_update_settings($mvctv_args) {
    $setting_val = $mvctv_args['setting_val'];
    
    $content = "<?php

\$api_key = '$setting_val';

?>
";
    
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    file_put_contents($settings_file, $content);
    
	echo 'ok';
}