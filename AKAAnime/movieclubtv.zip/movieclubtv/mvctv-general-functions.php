<?php


function mvctv_compile_template($template_file, $video_var){
    $template_file_path = 'templates/' . $template_file;
    $html = implode("\n", file($template_file_path));
    
    foreach($video_var as $key => $val){
        $html = preg_replace("/\[$key\]/", $video_var[$key],$html);
    }
    return $html;
}


function mvctvadmin_menu_page_url($input_args){
	#$input_args['lk_unique_session'] = session_id() . time();
	$input_args['mvctv_unique_session'] = time();
	$post_action = add_query_arg($input_args, admin_url('admin.php'));
	return $post_action;
}

function mvctv_menu_page_url($input_args){
    $input_args['mvctv_unique_session'] = time();
    $post_action = add_query_arg($input_args, admin_url('admin.php'));
    return $post_action;
}

function mvctv_input_filter($input_name,$default_val){
	$return_val = $default_val;
	if(isset($_GET["$input_name"])){
		$return_val = $_GET["$input_name"];
	}
	if(isset($_POST["$input_name"])){
		$return_val = $_POST["$input_name"];
	}
	return $return_val;
}

function get_bangkok_gmt_time(){
	$timezone  = 7;
	$time_now =  time() + 3600*($timezone+date("I"));
	return $time_now;
}

function mvctv_get_user_role(){
	global $current_user;
	$user_roles = $current_user->roles;
	
	$user_role = '';
	foreach( $user_roles as $role ) {
		$role = get_role( $role );
		if ( $role != null ){
			$user_role = $role->name;
		}
	}
	
	#$user_role = array_shift($user_roles);
	return $user_role;
}

?>