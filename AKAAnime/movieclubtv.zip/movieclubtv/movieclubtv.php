<?php

/**
 * @package Movie Club API
 */
/*
 Plugin Name: Movie Club API
 Plugin URI: http://uzaweb.com/wordpress-plugins/movie-clube-tv
 Description: Movie Club API
 Version: 1.0.1
 Author: Amarin Boonkirt
 Author URI: http://uzaweb.com
 License: -
 Text Domain: Movie Club API
 */

/*
 * movie-view Movie View [mvctv_movie_view template=movie_view.html]
 * series-view Series View [mvctv_series_view template=series_view.html]
 */

define('PRO_FOLDER', dirname(plugin_basename(__FILE__)));
define('MVCTV_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MVCTV_CLIENT_ID', get_current_user_id());
// production / development
define('MVCTV_DEV_MODE', 'production');
//define('MVCTV_DEV_MODE', 'development');
register_activation_hook( __FILE__, 'mvctv_activate' );
register_deactivation_hook(__FILE__ , 'mvctv_deactivation' );

add_action('admin_menu','regist_admin_menu');
add_action('after_setup_theme', 'remove_admin_bar');
add_action( 'wp_head', 'mvctv_head' );

add_action('wp_ajax_request_ajax', 'mvctv_ajax_callback');

function mvctv_head() {
    return '';
	$favicon =  home_url('/wp-content/plugins/mvctv-patent-analysis/frontend/images/favicon.ico');
	$htmlCode  = '
<link rel="icon"
      type="image/x-icon"
      href="'.$favicon.'">
<style type="text/css">
.site-info {
  display: none;
}
      		
</style>
	   <script type="text/javascript" src="'. plugins_url() .'/mvctv-patent-analysis/js/script.js"></script>';
	$htmlCode.= '<script>
var $ = jQuery.noConflict();
</script>';
	echo $htmlCode;
}

include_once 'mvctv-general-functions.php';

if(is_admin()){
	include_once 'mvctv-admin.php';
	include_once 'mvctv-user.php';
	//add_shortcode('mvctv_db_login', 'mvctv_db_login');	
	wp_enqueue_script('mvctv-admin-script1', plugin_dir_url(__FILE__) . 'js/common.js');
}else{
	add_shortcode('mvctv_home_cat_rendor', 'mvctv_home_cat_rendor');
	add_shortcode('mvctv_movie_view', 'mvctv_movie_view');
	add_shortcode('mvctv_concert_view', 'mvctv_concert_view');
	add_shortcode('mvctv_series_view', 'mvctv_series_view');
	add_shortcode('mvctv_category_view', 'mvctv_category_view');
}

wp_enqueue_style('mvctv-script1',"https://unpkg.com/video.js/dist/video-js.css");
wp_enqueue_script('mvctv-script2',"https://unpkg.com/video.js/dist/video.js");
wp_enqueue_script('mvctv-style1','https://unpkg.com/@videojs/http-streaming/dist/videojs-http-streaming.js');

wp_enqueue_style('mvctv-style2', plugin_dir_url(__FILE__) . 'frontend/css/common.css');

function mvctv_activate(){
	include_once 'mvctv-install.php';
	mvctv_install();
}

function mvctv_deactivation(){
	include_once 'mvctv-uninstall.php';
	mvctv_uninstall();
}

function mvctv_series_view($atts, $content = ''){
    $shortcut_args = shortcode_atts( array(    
        'template' => ''
    ), $atts );
    $shortcut_args['template'] = isset($shortcut_args['template']) ? $shortcut_args['template'] : 'series_view.html';
    
    $content = '';
    
    $mvctv_load_settings = mvctv_load_settings();
    include_once 'includes/MovieClubApiLib.php';
    $objMovieClubApi = new MovieClubApiLib($mvctv_load_settings['api_key']);
    
    $movie_id = mvctv_input_filter ( 'id', '' );
    $api_result_lists = $objMovieClubApi->get_series_info($movie_id);
    //print_r($api_result_lists);exit;
        
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/series_video_player.html';
    $template_data = implode("\n", file($template_file_path));
    
    $series_player_html = '';
    if(isset($api_result_lists['res']['link_series']) && count($api_result_lists['res']['link_series'])){        
        foreach($api_result_lists['res']['link_series'] as $key=>$value){
            $movie_item_html = $template_data;
            
            $link_series_var['ep_id'] = $api_result_lists['res']['link_series'][$key]['ep_id'];            
            $link_series_var['ep_title'] = $api_result_lists['res']['link_series'][$key]['ep_title'];
            $link_series_var['ep_img'] = $api_result_lists['res']['link_series'][$key]['ep_img'];
            $link_series_var['ep_link'] = $api_result_lists['res']['link_series'][$key]['ep_link'];
            
            $link_series_var['ep_link_url'] = base64_decode($api_result_lists['res']['link_series'][$key]['ep_link']);
            
            $link_series_var['series_id'] = $api_result_lists['res']['link_series'][$key]['series_id'];
            $link_series_var['admin_id'] = $api_result_lists['res']['link_series'][$key]['admin_id'];
            $link_series_var['dt_insert_ep'] = $api_result_lists['res']['link_series'][$key]['dt_insert_ep'];
            $link_series_var['dt_update_ep'] = $api_result_lists['res']['link_series'][$key]['dt_update_ep'];
            $link_series_var['admin_id_update'] = $api_result_lists['res']['link_series'][$key]['admin_id_update'];
            
            foreach($link_series_var as $videokey => $videoval){
                $movie_item_html = preg_replace("/\[$videokey\]/", $link_series_var[$videokey],$movie_item_html);
            }
            $series_player_html .= $movie_item_html;            
        }        
    }
    
    $series_soundtrack_player_html = '';
    if(isset($api_result_lists['res']['link_series_soundtrack']) && count($api_result_lists['res']['link_series_soundtrack'])){
        foreach($api_result_lists['res']['link_series_soundtrack'] as $key=>$value){
            $movie_item_html = $template_data;
            
            $link_series_var['ep_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_id'];
            $link_series_var['ep_title'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_title'];
            $link_series_var['ep_img'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_img'];
            $link_series_var['ep_link'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_link'];
            
            $link_series_var['ep_link_url'] = base64_decode($api_result_lists['res']['link_series_soundtrack'][$key]['ep_link']);
            
            $link_series_var['series_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['series_id'];
            $link_series_var['admin_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['admin_id'];
            $link_series_var['dt_insert_ep'] = $api_result_lists['res']['link_series_soundtrack'][$key]['dt_insert_ep'];
            $link_series_var['dt_update_ep'] = $api_result_lists['res']['link_series_soundtrack'][$key]['dt_update_ep'];
            $link_series_var['admin_id_update'] = $api_result_lists['res']['link_series_soundtrack'][$key]['admin_id_update'];
            
            foreach($link_series_var as $videokey => $videoval){
                $movie_item_html = preg_replace("/\[$videokey\]/", $link_series_var[$videokey],$movie_item_html);
            }
            $series_soundtrack_player_html .= $movie_item_html;
        }
    }    
    
    $details_var = $api_result_lists['res']['series_details'][0];
    /*
    $details_var['series_id'] = $api_result_lists['res']['series_details'][0]['movies_link_id'];
    $details_var['series_title'] = $api_result_lists['res']['series_details'][0]['series_title'];
    $details_var['series_title_eng'] = $api_result_lists['res']['series_details'][0]['series_title_eng'];
    $details_var['series_img_vertical'] = $api_result_lists['res']['series_details'][0]['series_img_vertical'];
    $details_var['series_img_slide'] = $api_result_lists['res']['series_details'][0]['series_img_slide'];
    
    $details_var['series_img_bg'] = $api_result_lists['res']['series_details'][0]['series_img_bg'];
    $details_var['series_trailer'] = $api_result_lists['res']['series_details'][0]['series_trailer'];
    
    $details_var['series_description'] = $api_result_lists['res']['series_details'][0]['series_description'];
    $details_var['series_description_eng'] = $api_result_lists['res']['series_details'][0]['series_description_eng'];
        
    $details_var['series_imdb_id'] = $api_result_lists['res']['series_details'][0]['series_imdb_id'];
    $details_var['series_view'] = $api_result_lists['res']['series_details'][0]['series_view'];
    $details_var['is_slide_img'] = $api_result_lists['res']['series_details'][0]['is_slide_img'];
    $details_var['admin_id'] = $api_result_lists['res']['series_details'][0]['admin_id'];
    $details_var['creators'] = $api_result_lists['res']['series_details'][0]['creators'];
    $details_var['stars'] = $api_result_lists['res']['series_details'][0]['stars'];
    $details_var['years'] = $api_result_lists['res']['series_details'][0]['years'];
    $details_var['is_hidden'] = $api_result_lists['res']['series_details'][0]['is_hidden'];
    $details_var['series_imdb'] = $api_result_lists['res']['series_details'][0]['series_imdb'];
    $details_var['series_time'] = $api_result_lists['res']['series_details'][0]['series_time'];
    $details_var['dt_insert'] = $api_result_lists['res']['series_details'][0]['dt_insert'];
    $details_var['dt_last_update'] = $api_result_lists['res']['series_details'][0]['dt_last_update'];
    $details_var['admin_id_update'] = $api_result_lists['res']['series_details'][0]['admin_id_update'];
    $details_var['img_path'] = $api_result_lists['res']['series_details'][0]['img_path'];
    */
    
    $details_var['img_series_vertical_url'] = $details_var['img_path'] . $details_var['series_img_vertical'];
    
    $details_var['series_player'] = $series_player_html;
    $details_var['series_soundtrack_player'] = $series_soundtrack_player_html;
    
    $mvctv_template = $shortcut_args['template'];
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/' . $mvctv_template;
    $series_detail_html = implode("\n", file($template_file_path));
    foreach($details_var as $videokey => $videoval){
        $series_detail_html = preg_replace("/\[$videokey\]/", $details_var[$videokey],$series_detail_html);
    }
    
    $content .= $series_detail_html;
    
    echo $content;
    //print_r($movie_item_html);exit;
}

function mvctv_concert_view($atts, $content = ''){
    $shortcut_args = shortcode_atts( array(
        'template' => ''
    ), $atts );
    $shortcut_args['template'] = isset($shortcut_args['template']) ? $shortcut_args['template'] : 'concert_view.html';
    
    $content = '';
    
    $mvctv_load_settings = mvctv_load_settings();
    include_once 'includes/MovieClubApiLib.php';
    $objMovieClubApi = new MovieClubApiLib($mvctv_load_settings['api_key']);
    
    $concert_id = mvctv_input_filter ( 'id', '' );
    $api_result_lists = $objMovieClubApi->get_concert_info($concert_id);
    //print_r($api_result_lists);exit;
    
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/concert_video_player.html';
    $template_data = implode("\n", file($template_file_path));
    
    $series_player_html = '';
    if(isset($api_result_lists['res']['link_series']) && count($api_result_lists['res']['link_series'])){
        foreach($api_result_lists['res']['link_series'] as $key=>$value){
            $movie_item_html = $template_data;
            
            $link_series_var['ep_id'] = $api_result_lists['res']['link_series'][$key]['ep_id'];
            $link_series_var['ep_title'] = $api_result_lists['res']['link_series'][$key]['ep_title'];
            $link_series_var['ep_img'] = $api_result_lists['res']['link_series'][$key]['ep_img'];
            $link_series_var['ep_link'] = $api_result_lists['res']['link_series'][$key]['ep_link'];
            
            $link_series_var['ep_link_url'] = base64_decode($api_result_lists['res']['link_series'][$key]['ep_link']);
            
            $link_series_var['series_id'] = $api_result_lists['res']['link_series'][$key]['series_id'];
            $link_series_var['admin_id'] = $api_result_lists['res']['link_series'][$key]['admin_id'];
            $link_series_var['dt_insert_ep'] = $api_result_lists['res']['link_series'][$key]['dt_insert_ep'];
            $link_series_var['dt_update_ep'] = $api_result_lists['res']['link_series'][$key]['dt_update_ep'];
            $link_series_var['admin_id_update'] = $api_result_lists['res']['link_series'][$key]['admin_id_update'];
            
            foreach($link_series_var as $videokey => $videoval){
                $movie_item_html = preg_replace("/\[$videokey\]/", $link_series_var[$videokey],$movie_item_html);
            }
            $series_player_html .= $movie_item_html;
        }
    }
    
    $series_soundtrack_player_html = '';
    if(isset($api_result_lists['res']['link_series_soundtrack']) && count($api_result_lists['res']['link_series_soundtrack'])){
        foreach($api_result_lists['res']['link_series_soundtrack'] as $key=>$value){
            $movie_item_html = $template_data;
            
            $link_series_var['ep_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_id'];
            $link_series_var['ep_title'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_title'];
            $link_series_var['ep_img'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_img'];
            $link_series_var['ep_link'] = $api_result_lists['res']['link_series_soundtrack'][$key]['ep_link'];
            
            $link_series_var['ep_link_url'] = base64_decode($api_result_lists['res']['link_series_soundtrack'][$key]['ep_link']);
            
            $link_series_var['series_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['series_id'];
            $link_series_var['admin_id'] = $api_result_lists['res']['link_series_soundtrack'][$key]['admin_id'];
            $link_series_var['dt_insert_ep'] = $api_result_lists['res']['link_series_soundtrack'][$key]['dt_insert_ep'];
            $link_series_var['dt_update_ep'] = $api_result_lists['res']['link_series_soundtrack'][$key]['dt_update_ep'];
            $link_series_var['admin_id_update'] = $api_result_lists['res']['link_series_soundtrack'][$key]['admin_id_update'];
            
            foreach($link_series_var as $videokey => $videoval){
                $movie_item_html = preg_replace("/\[$videokey\]/", $link_series_var[$videokey],$movie_item_html);
            }
            $series_soundtrack_player_html .= $movie_item_html;
        }
    }
    
    $details_var = $api_result_lists['res']['series_details'][0];
    /*
     $details_var['series_id'] = $api_result_lists['res']['series_details'][0]['movies_link_id'];
     $details_var['series_title'] = $api_result_lists['res']['series_details'][0]['series_title'];
     $details_var['series_title_eng'] = $api_result_lists['res']['series_details'][0]['series_title_eng'];
     $details_var['series_img_vertical'] = $api_result_lists['res']['series_details'][0]['series_img_vertical'];
     $details_var['series_img_slide'] = $api_result_lists['res']['series_details'][0]['series_img_slide'];
     
     $details_var['series_img_bg'] = $api_result_lists['res']['series_details'][0]['series_img_bg'];
     $details_var['series_trailer'] = $api_result_lists['res']['series_details'][0]['series_trailer'];
     
     $details_var['series_description'] = $api_result_lists['res']['series_details'][0]['series_description'];
     $details_var['series_description_eng'] = $api_result_lists['res']['series_details'][0]['series_description_eng'];
     
     $details_var['series_imdb_id'] = $api_result_lists['res']['series_details'][0]['series_imdb_id'];
     $details_var['series_view'] = $api_result_lists['res']['series_details'][0]['series_view'];
     $details_var['is_slide_img'] = $api_result_lists['res']['series_details'][0]['is_slide_img'];
     $details_var['admin_id'] = $api_result_lists['res']['series_details'][0]['admin_id'];
     $details_var['creators'] = $api_result_lists['res']['series_details'][0]['creators'];
     $details_var['stars'] = $api_result_lists['res']['series_details'][0]['stars'];
     $details_var['years'] = $api_result_lists['res']['series_details'][0]['years'];
     $details_var['is_hidden'] = $api_result_lists['res']['series_details'][0]['is_hidden'];
     $details_var['series_imdb'] = $api_result_lists['res']['series_details'][0]['series_imdb'];
     $details_var['series_time'] = $api_result_lists['res']['series_details'][0]['series_time'];
     $details_var['dt_insert'] = $api_result_lists['res']['series_details'][0]['dt_insert'];
     $details_var['dt_last_update'] = $api_result_lists['res']['series_details'][0]['dt_last_update'];
     $details_var['admin_id_update'] = $api_result_lists['res']['series_details'][0]['admin_id_update'];
     $details_var['img_path'] = $api_result_lists['res']['series_details'][0]['img_path'];
     */
    
    $details_var['img_series_vertical_url'] = $details_var['img_path'] . $details_var['series_img_vertical'];
    
    $details_var['series_player'] = $series_player_html;
    $details_var['series_soundtrack_player'] = $series_soundtrack_player_html;
    
    $mvctv_template = $shortcut_args['template'];
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/' . $mvctv_template;
    $series_detail_html = implode("\n", file($template_file_path));
    foreach($details_var as $videokey => $videoval){
        $series_detail_html = preg_replace("/\[$videokey\]/", $details_var[$videokey],$series_detail_html);
    }
    
    $content .= $series_detail_html;
    
    echo $content;
    //print_r($movie_item_html);exit;
}

function mvctv_movie_view($atts, $content = ''){
    $shortcut_args = shortcode_atts( array(
        'template' => ''
    ), $atts );
    $shortcut_args['template'] = isset($shortcut_args['template']) ? $shortcut_args['template'] : 'movie_view.html';
    
    $mvctv_load_settings = mvctv_load_settings();
    include_once 'includes/MovieClubApiLib.php';
    $objMovieClubApi = new MovieClubApiLib($mvctv_load_settings['api_key']);
    
    $content = '';
    
    $movie_id = mvctv_input_filter ( 'id', '' );    
    $api_result_lists = $objMovieClubApi->get_movie_info($movie_id);
    //print_r($api_result_lists);exit;
        
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/movie_video_player.html';
    $template_data = implode("\n", file($template_file_path));
    $movie_player_html = '';
    if(isset($api_result_lists['res']['link_movie']) && count($api_result_lists['res']['link_movie'])){
        foreach($api_result_lists['res']['link_movie'] as $key=>$value){
            $movie_item_html = $template_data;
             
            $link_movie_var = array();
            $link_movie_var = $api_result_lists['res']['link_movie'][$key];
            $link_movie_var['link_movies_url'] = base64_decode($api_result_lists['res']['link_movie'][$key]['link_movies']);
             
            foreach($link_movie_var as $videokey => $videoval){
               $movie_item_html = preg_replace("/\[$videokey\]/", $link_movie_var[$videokey],$movie_item_html);
            }
            $movie_player_html .= $movie_item_html;
        }        
     }
    
    $video_details_var = $api_result_lists['res']['movie_details'][0];
    $video_details_var['movies_img_vertical_url'] = $video_details_var['img_path'] . $video_details_var['movies_img_vertical'];
    $video_details_var['trailer_embed_code'] = base64_decode($video_details_var['trailer_embed']);
    $video_details_var['movie_player'] = $movie_player_html;
    $mvctv_template = $shortcut_args['template'];
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/' . $mvctv_template;
    $template_data = implode("\n", file($template_file_path));
    foreach($video_details_var as $videokey => $videoval){
        $template_data = preg_replace("/\[$videokey\]/", $video_details_var[$videokey],$template_data);
    }
    $content .= $template_data;

    echo $content;
}

function mvctv_home_cat_rendor($atts, $content = ''){
    $shortcut_args = shortcode_atts( array(
        'cats' => '',
        'template' => ''
    ), $atts );
    
    $mvctv_load_settings = mvctv_load_settings();
    include_once 'includes/MovieClubApiLib.php';
    $objMovieClubApi = new MovieClubApiLib($mvctv_load_settings['api_key']);
    
    $shortcut_args['cats'] = isset($shortcut_args['cats']) ? $shortcut_args['cats'] : '';
    if($shortcut_args['cats'] == ''){
        return '';
    }
    $shortcut_args['template'] = isset($shortcut_args['template']) ? $shortcut_args['template'] : 'cat_video.html';
    
    $mvctv_cats = $shortcut_args['cats'];
    $mvctv_template = $shortcut_args['template'];
    
    $mvctv_cats_lists = explode(',', $mvctv_cats);
    
    //$api_result_lists1 = $objMovieClubApi->get_category_info('32');
    //print_r($api_result_lists1);exit;
    
    $content = '';
    foreach($mvctv_cats_lists as $cat_id){
        /*
        $api_result_lists1 = $objMovieClubApi->get_category_info($cat_id);
        $category_title_th = $api_result_lists1['res']['category_title_th'];
        $category_title_en = $api_result_lists1['res']['category_title_en'];
        
        $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id;
        
        $content .= sprintf('<div id="mvctv_cat_%s" class="mvctv_cat_title"><a href="%s">%s</a></div>', $cat_id, $cat_view_external_link, $category_title_th);
        
        $api_result_lists = $objMovieClubApi->get_all_video_categories($cat_id);
        //print_r($api_result_lists);exit; //<a href="https://www.movieclub.tv/series/detail/8438"
        $template_file_path = MVCTV_PLUGIN_DIR . '/templates/' . $mvctv_template;
        $template_data = implode("\n", file($template_file_path));
        
        $content .= sprintf('<div id="mvctv_cat_video_list%s" class="mvctv_cat_video_list">', $cat_id);
        
        foreach($api_result_lists['res'] as $key => $val){
            $video_var = array();
            $video_var = $api_result_lists['res'][$key];
            
            $video_var['vdo_image_url'] = $video_var['vdo_img_path'] . $video_var['vdo_image'];
            $video_var['describe_type_en'] = '<div class="describe_type_eng">';
            $video_var['describe_type_th'] = '<div class="describe_type_th">';
            
            if($video_var['vdo_type'] == 's'){
                $video_var['vdo_type_name'] = 'Series';
                $video_var['video_external_link'] = get_permalink(get_page_by_path('series-view')) . '?id='.$video_var['vdo_id'];
                if(count($video_var['ep_seires'])){
                    $video_var['describe_type_th'] .= '<div class="thai">พากย์ไทย</div>';
                    $video_var['describe_type_en'] .= '<div class="thai">Thai</div>';
                }
                if(count($video_var['ep_series_soundtrack'])){
                    $video_var['describe_type_th'] .= '<div class="soundtrack">ซาวด์แทร็ก</div>';
                    $video_var['describe_type_en'] .= '<div class="soundtrack">Soundtrack</div>';
                }
            }
            if ($video_var['vdo_type'] == 'm'){
                $video_var['vdo_type_name'] = 'Movie';
                $video_var['video_external_link'] = get_permalink(get_page_by_path('movie-view')) . '?id='.$video_var['vdo_id'];
                foreach($video_var['link_movies'] as $movieNo => $movieValue){
                    $video_var['describe_type_th'] .= sprintf('<div class="%s">%s</div>',$video_var['link_movies'][$movieNo]['type']['describe_link'],$video_var['link_movies'][$movieNo]['type']['describe_type']);
                    $video_var['describe_type_en'] .= sprintf('<div class="%s">%s</div>',$video_var['link_movies'][$movieNo]['type']['describe_link'],$video_var['link_movies'][$movieNo]['type']['describe_type_eng']);
                }
            }
            $video_var['describe_type_en'] .= '</div>';
            $video_var['describe_type_th'] .= '</div>';
            
            //replace dimension 1
            $movie_item_html = $template_data;
            foreach($video_var as $videokey => $videoval){
                if(is_array($video_var[$videokey])){
                    continue;
                }
                if($videoval == 'null'){
                    $videoval = '';
                }
                $movie_item_html = preg_replace("/\[$videokey\]/", $videoval,$movie_item_html);
            }
            $content .= $movie_item_html;
        }
        */
        $content .= get_video_cat_list_by_cat_id($cat_id,1,$mvctv_template);
        $content .= '</div>';
    }
    echo $content;
}

function mvctv_category_view($atts, $content = ''){
    $shortcut_args = shortcode_atts( array(
        'template' => ''
    ), $atts );
    $mvctv_template = isset($shortcut_args['template']) ? $shortcut_args['template'] : 'category_view.html';
        
    $cat_id = mvctv_input_filter ( 'id', '' );
    $pager = mvctv_input_filter ( 'pager', '1' );
    
    //$videooffset = $videooffset != '' ? $videooffset : 1;
    
    $content = get_video_cat_list_by_cat_id($cat_id,$pager,$mvctv_template);
    
    echo $content;
}

function get_video_cat_list_by_cat_id($cat_id, $pager, $mvctv_template){
    
    
    $content = '';
    $mvctv_load_settings = mvctv_load_settings();
    include_once 'includes/MovieClubApiLib.php';
    $objMovieClubApi = new MovieClubApiLib($mvctv_load_settings['api_key']);
    
    $mvctv_template = isset($mvctv_template) ? $mvctv_template : 'cat_video.html';
    
    $content = '';
     
    $videooffset = 1;
    if($pager > 1){
        $videooffset = ($pager - 1) * 10; 
    }
    
    $api_result_lists = $objMovieClubApi->get_all_video_categories($cat_id,$videooffset);
    if($api_result_lists['status'] == ''){
        return $content;
    }
    
    $api_result_lists1 = $objMovieClubApi->get_category_info($cat_id);
    $category_title_th = $api_result_lists1['res']['category_title_th'];
    $category_title_en = $api_result_lists1['res']['category_title_en'];
    $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id;
    $content .= sprintf('<div id="mvctv_cat_%s" class="mvctv_cat_title"><a href="%s">%s</a></div>', $cat_id, $cat_view_external_link, $category_title_th);
    
    //print_r($api_result_lists);exit; //<a href="https://www.movieclub.tv/series/detail/8438"
    $template_file_path = MVCTV_PLUGIN_DIR . '/templates/' . $mvctv_template;
    $template_data = implode("\n", file($template_file_path));
        
    $content .= sprintf('<div id="mvctv_cat_video_list%s" class="mvctv_cat_video_list">', $cat_id);
    
    foreach($api_result_lists['res'] as $key => $val){
        $video_var = array();
        $video_var = $api_result_lists['res'][$key];
            
        $video_var['vdo_image_url'] = $video_var['vdo_img_path'] . $video_var['vdo_image'];
        $video_var['describe_type_en'] = '<div class="describe_type_eng">';
        $video_var['describe_type_th'] = '<div class="describe_type_th">';
        
        if($video_var['vdo_type'] == 'c'){
            #continue;
        }
        
        if($video_var['vdo_type'] == 'c'){
            $video_var['vdo_type_name'] = 'Concert';
            $video_var['video_external_link'] = get_permalink(get_page_by_path('concert-view')) . '?id='.$video_var['vdo_id'];
            if(count($video_var['link_concert'])){
                $video_var['describe_type_th'] .= '<div class="thai">พากย์ไทย</div>';
                $video_var['describe_type_en'] .= '<div class="thai">Thai</div>';
            }
            if(count($video_var['ep_series_soundtrack'])){
                $video_var['describe_type_th'] .= '<div class="soundtrack">ซาวด์แทร็ก</div>';
                $video_var['describe_type_en'] .= '<div class="soundtrack">Soundtrack</div>';
            }
        }
        
        if($video_var['vdo_type'] == 's'){
            $video_var['vdo_type_name'] = 'Series';
            $video_var['video_external_link'] = get_permalink(get_page_by_path('series-view')) . '?id='.$video_var['vdo_id'];
            if(count($video_var['ep_seires'])){
                $video_var['describe_type_th'] .= '<div class="thai">พากย์ไทย</div>';
                $video_var['describe_type_en'] .= '<div class="thai">Thai</div>';
            }
            if(count($video_var['ep_series_soundtrack'])){
                $video_var['describe_type_th'] .= '<div class="soundtrack">ซาวด์แทร็ก</div>';
                $video_var['describe_type_en'] .= '<div class="soundtrack">Soundtrack</div>';
            }
        }
        if ($video_var['vdo_type'] == 'm'){
            $video_var['vdo_type_name'] = 'Movie';
            $video_var['video_external_link'] = get_permalink(get_page_by_path('movie-view')) . '?id='.$video_var['vdo_id'];
            foreach($video_var['link_movies'] as $movieNo => $movieValue){
                $video_var['describe_type_th'] .= sprintf('<div class="%s">%s</div>',$video_var['link_movies'][$movieNo]['type']['describe_link'],$video_var['link_movies'][$movieNo]['type']['describe_type']);
                $video_var['describe_type_en'] .= sprintf('<div class="%s">%s</div>',$video_var['link_movies'][$movieNo]['type']['describe_link'],$video_var['link_movies'][$movieNo]['type']['describe_type_eng']);
            }
        }
        $video_var['describe_type_en'] .= '</div>';
        $video_var['describe_type_th'] .= '</div>';
            
        //replace dimension 1
        $movie_item_html = $template_data;
        foreach($video_var as $videokey => $videoval){
            if(is_array($video_var[$videokey])){
                continue;
            }
            if($videoval == 'null'){
                $videoval = '';
            }
            $movie_item_html = preg_replace("/\[$videokey\]/", $videoval,$movie_item_html);
        }
        $content .= $movie_item_html;
    }
        
    $content .= '</div>'; // 1 10 20 30
    
    //$videooffset = 5;  //  1 2 3 4 5 6 7 8 9 10
    $pager_content = '<div class="category_pager"><ul class="ul_category_pager">';
    $currentpager = $pager;
    
    $page_begin = 1;
    $page_end = 5;
    //  1 2 3 4 5 >
    if($currentpager > 5){ // < 4 5 6 7 8 9 10 >
        $page_begin = $currentpager - 3;
        $page_end = $currentpager + 3;
        $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id . '&pager='. ($page_begin-1);
        $pager_content .= sprintf('<li><a href="%s">&lt;</li>', $cat_view_external_link);
        
        $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id . '&pager='. ($page_begin-3);
        $pager_content .= sprintf('<li><a href="%s">&lt;&lt;</li>', $cat_view_external_link);
    }
    
    //$pager_content .= "currentpager = $currentpager";
    
    for($pagerno=$page_begin;$pagerno<=$page_end;$pagerno++){
        $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id . '&pager='.$pagerno;
        if($pagerno == $currentpager){            
            $pager_content .= sprintf('<li class="current"><a href="%s">%s</li>', $cat_view_external_link, $pagerno);
        }else{
            $pager_content .= sprintf('<li><a href="%s">%s</a></li>', $cat_view_external_link, $pagerno);
        }
    }
    
    $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id . '&pager='.($page_end+1);
    $pager_content .= sprintf('<li><a href="%s">&gt;</li>', $cat_view_external_link);
    
    $cat_view_external_link = get_permalink(get_page_by_path('category-view')) . '?id='.$cat_id . '&pager='.($page_end+3);
    $pager_content .= sprintf('<li><a href="%s">&gt;&gt;</li>', $cat_view_external_link);
    
    $pager_content .= '</ul></div>';
    $content .= $pager_content;
    
    return $content;
}

/* https://codex.wordpress.org/Function_Reference/add_menu_page */
#https://codex.wordpress.org/Roles_and_Capabilities
#https://developer.wordpress.org/resource/dashicons/#feedback
function regist_admin_menu() {
	/*add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );*/
	//add_menu_page( 'Virtual Race', 'Virtual Race', __FILE__,'mvctvadmin_main_page','dashicons-universal-access-alt', 21 );
	
	//add_submenu_page('Settings', 'Settings', 'Settings', '4', 'Settings', 'mvctvadmin_settings');
	
	
	
    add_menu_page( 'MovieClubTV', 'MovieClubTV', 'mvctvadmin_main_page', __FILE__, 'mvctvadmin_main_page','dashicons-video-alt3', 21 );
    #add_submenu_page(__FILE__, 'Customers', 'Customers', '8', 'lk-customers', 'lkadmin_customers_page');
    add_submenu_page(__FILE__, 'Movie Category', 'Movie Category', '8', 'mvctv-category', 'mvctvadmin_main_page');
    add_submenu_page(__FILE__, 'Template', 'Template', '8', 'mvctv-template', 'mvctvadmin_template_page');
    add_submenu_page(__FILE__, 'API Settings', 'API Settings', '8', 'mvctv-setting', 'mvctvadmin_settings_page');
	
	
	$user_role = mvctv_get_user_role();
	if($user_role == 'administrator'){
		//add_menu_page('Patent Analysis Selection', 'Patent Analysis Selectionสั่งซื้อ', 0, 'mvctv-user-searchdb-select','mvctv_user_searchdb_select','dashicons-cart',21);
		
	}
}



function mvctvadmin_main_page() {	
	$mvctv_action = mvctv_input_filter ( 'mvctv_action', '' );	
		
	$content = <<<HTML
<h2>Using</h2>
<pre>
<strong>1 Create Movie View Page</strong>
Page Name: Movie View
Permalink: movie-view
Content: [mvctv_movie_view template=movie_view.html]

<strong>2 Create Series View Page</strong>
Page Name: Series View
Permalink: series-view
Content: [mvctv_series_view template=series_view.html]

<strong>3 Add short code in home page</strong>
[mvctv_home_cat_rendor cats=32,35 template=cat_video.html]
</pre>		
		
HTML;
		
	echo $content;
}

function mvctvadmin_template_page() {
    
    $mvctv_action = mvctv_input_filter ( 'mvctv_action', '' );    
    $wp_site_url = get_site_url();
    $content = <<<HTML
<br >
<br >
<h3>Templates</h3>
<pre>
Cat video list in home page: <a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?plugin=movieclubtv%2Fmovieclubtv.php&file=movieclubtv%2Ftemplates%2Fcat_video.html">cat_video.html</a>

Movie View Page: <a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?plugin=movieclubtv%2Fmovieclubtv.php&file=movieclubtv%2Ftemplates%2Fmovie_view.html">movie_view.html</a>
Movie Video Player Section: <a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?plugin=movieclubtv%2Fmovieclubtv.php&file=movieclubtv%2Ftemplates%2Fmovie_video_player.html">movie_video_player.html</a>

Series View Page: <a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?plugin=movieclubtv%2Fmovieclubtv.php&file=movieclubtv%2Ftemplates%2Fseries_view.html">series_view.html</a>
Series Video Player Section: <a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?plugin=movieclubtv%2Fmovieclubtv.php&file=movieclubtv%2Ftemplates%2Fseries_video_player.html">series_video_player.html</a>
</pre>
<h3>CSS</h3>
<a target="_blank" href="$wp_site_url/wp-admin/plugin-editor.php?file=movieclubtv%2Ffrontend%2Fcss%2Fcommon.css&plugin=movieclubtv%2Fmovieclubtv.php">frontend/css/common.css</a>
HTML;
        
    echo $content;
}

function mvctvadmin_settings_page() {
    
    $mvctv_settings = mvctv_load_settings();
    
    $mvctv_settings_api_key = $mvctv_settings['api_key'];
    $content = <<<HTML
<h2>Settings</h2>

API KEY: <input onblur="updateMvctvSettings('api_key',this.value)" type="text" size="40" value="$mvctv_settings_api_key">
HTML;
        
    echo $content;
}

function mvctv_load_settings() {    
    $mvctv_settings = array();
    $mvctv_settings['api_key'] = '';    
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    include $settings_file;
    
    if(isset($api_key) && $api_key != ''){
        $mvctv_settings['api_key'] = $api_key;
    }
    return $mvctv_settings;
}

function mvctv_ajax_callback(){
    include_once 'mvctv-ajax-functions.php';
    $mvctv_action = mvctv_input_filter ( 'mvctv_action', '' );
    $mvctv_args = mvctv_input_filter ( 'mvctv_args', array() );
    if(allow_mvctv_ajax_func($mvctv_action)){
        call_user_func_array($mvctv_action, array($mvctv_args));
    }else{
        wp_die('Not found method ' . $mvctv_action);
    }
    wp_die(); // this is required to terminate immediately and return a proper response
}
function allow_mvctv_ajax_func($func_name)
{
    $is_allow_func = false;
    $allow_func = array(
        'mvctv_update_settings' => 1
    );
    if (array_key_exists($func_name, $allow_func)) {
        $is_allow_func = true;
    }
    #if (function_exists('imap_open')) {
    return $is_allow_func;
}

function remove_admin_bar() {
	if (!current_user_can('administrator') && !is_admin()) {
		show_admin_bar(false);
	}
}

?>