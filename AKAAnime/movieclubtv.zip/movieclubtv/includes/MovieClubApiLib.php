<?php

/*
https://app.movieclub.tv/api/
*/

class MovieClubApiLib {
    private $mvcConf = array();    
    
    public function MovieClubApiLib($mvctv_api_key = ''){
        $this->mvcConf['X_API_KEY'] = $mvctv_api_key;
        $this->mvcConf['mv_debug'] = 0;
        $this->mvcConf['mv_disable_cache'] = 0;
    }
    
    public function get_all_categories() {
        $action_url = '/categories/all';
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";
        }
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        if($this->mvcConf['mv_debug']){
            echo '<pre>';
            print_r($api_result_lists);
            echo '</pre>';
        }
        return $api_result_lists;
    }
    
    public function get_all_video_categories($cat_id_lists = '', $videooffset) {
        //$api_result_lists = $this->get_api_contents('/categories/all',$this->mvcConf['X_API_KEY']);
        $video_limit = '10';
        //$videooffset = '1';
        $action_url = sprintf('/vdo/all?limit=%s&offset=%s&category=%s',$video_limit,$videooffset,$cat_id_lists);
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";
        }
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        if($this->mvcConf['mv_debug']){
            echo '<pre>';
            print_r($api_result_lists);
            echo '</pre>';
        }
        return $api_result_lists;
    }
    
    public function get_category_info($cat_id = '') {
        $action_url = sprintf('/categories/id?category_id=%s',$cat_id);
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";
        }
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        
        return $api_result_lists;
    }
    
    public function get_movie_info($movie_id = '') {    
        $action_url = sprintf('/vdo/movie?movie_id=%s',$movie_id);        
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";
            echo '<pre>';
            print_r($api_result_lists);
            echo '</pre>';
        }
        return $api_result_lists;
    }
    
    public function get_series_info($series_id = '') {
        $action_url = sprintf('/vdo/series?series_id=%s',$series_id);
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";            
            echo '<pre>';
            print_r($api_result_lists);
            echo '</pre>';            
        }
        return $api_result_lists;
    }
    
    public function get_concert_info($concert_id = '') {
        $action_url = sprintf('/vdo/concert?concert_id=%s',$concert_id);
        $api_result_lists = $this->get_api_contents($action_url,$this->mvcConf['X_API_KEY']);
        if($this->mvcConf['mv_debug']){
            echo "DEBUG URL: $action_url <br/>";
            
            echo '<pre>';
            print_r($api_result_lists);
            echo '</pre>';
            
        }
        return $api_result_lists;
    }
    
    
    public function get_api_contents($action, $api_key){        
        $cache_path = plugin_dir_path(__FILE__) . '../cache';        
        $cache_file_name = md5($action);
        $cache_file_path = $cache_path . '/' . $cache_file_name;
        
        $need_new_data = 1;
        if(is_file($cache_file_path)){
            if (time()-filemtime($cache_file_path) > 6 * 3600) {
                // file older than 6 hours
                if($this->mvcConf['mv_debug']){
                    echo "file older than 6 hours";
                }                
            }else{
                // file younger than 6 hours
                if($this->mvcConf['mv_debug']){
                    echo "file younger than 6 hours";
                    $need_new_data = 0;
                }
            }
        }
        
        if($this->mvcConf['mv_disable_cache']){
            $need_new_data = 0;
        }
        
        if ($need_new_data) {
            
            $headers = array();
            $site = 'https://app.movieclub.tv/api';
            $url = $site . $action;
            
            $headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
            $headers[] = 'Accept: application/json';
            $headers[] = 'X-API-KEY: ' . $api_key;
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_USERAGENT, "{$_SERVER['SERVER_NAME']}");
            curl_setopt($ch, CURLOPT_URL, $url);
            
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            if(FALSE === ($retval = curl_exec($ch))) {
                error_log(curl_error($ch));
            } else {
                file_put_contents($cache_file_path, $retval);
                return json_decode($retval, true);
            }
        } else {            
            $retval = file_get_contents($cache_file_path);
            return json_decode($retval, true);
        }
        
    }
}

?>

